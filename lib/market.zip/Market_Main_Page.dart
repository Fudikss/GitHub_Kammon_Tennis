import 'dart:async';
import 'dart:developer';
import 'package:circular_menu/circular_menu.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:date_format/date_format.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:snstennis/account/user_account_info.dart';
import 'package:snstennis/club/first_screen_1_0.dart';
import 'package:snstennis/home.dart';
import 'package:snstennis/instant/instant_main.dart';
import 'package:snstennis/market/Market_Chat_Room.dart';
import 'package:snstennis/market/Market_Item_Info.dart';
import 'package:snstennis/market/Market_Item_Post_Write.dart';
import 'package:snstennis/market/Market_User_Buy_List.dart';
import 'package:snstennis/market/Market_User_Sell_List.dart';

class MarketMainPage extends StatefulWidget {
  final List item_id;

  const MarketMainPage({Key? key, required this.item_id}) : super(key: key);

  @override
  _MarketMainPageState createState() => _MarketMainPageState(item_id);
}

class _MarketMainPageState extends State<MarketMainPage>
    with TickerProviderStateMixin {
  List Market_Item_ID_List = [];
  List data = [];
  late List chat_data = [];
  late List total_chat_id = [];
  int _selectedNaviIndex = 3;

  List test_total_chat_id = [];

  List total_image_list = [];

  User user = FirebaseAuth.instance.currentUser!;

  TextEditingController _controller = TextEditingController();

  _MarketMainPageState(
    this.Market_Item_ID_List,
  );

  Future _get_item_image() async {
    print("_get_item_image 호출함");
  }

  ///
  /// 마켓 전체 게시글을 가져오는 함수
  ///
  // Future _getItem(List item_id) async {
  //   print("_getItem 호출함");
  //   List image_list = [];
  //   data.clear();
  //   total_image_list.clear();
  //   CollectionReference refMarket =
  //       FirebaseFirestore.instance.collection("Market");

  //   for (int i = 0; i < item_id.length; i++) {
  //     DocumentSnapshot snapitemshot = await refMarket.doc(item_id[i]).get();

  //     data.add(snapitemshot.data());

  //     var storageReference = FirebaseStorage.instance
  //         .ref()
  //         .child("Market")
  //         .child(item_id[i].toString())
  //         .child(data[i]["ImageUrl"][0].toString());

  //     image_list.add(await storageReference.getDownloadURL());

  //     total_image_list.add(image_list[i].toString());

  //     print(total_image_list);
  //   }
  //   return data;
  // }

  Future _getItem(List item_id) async {
    print("_getItem 호출함");
    // List image_list = [];
    data.clear();

    CollectionReference refMarket =
        FirebaseFirestore.instance.collection("Market");

    for (int i = 0; i < item_id.length; i++) {
      DocumentSnapshot snapitemshot = await refMarket.doc(item_id[i]).get();

      data.add(snapitemshot.data());
    }

    return data;
  }

  Widget _market_Chat_Room() {
    UserAccountInfo userAccount_ = Provider.of(context, listen: false);
    return Container(
      height: MediaQuery.of(context).size.height / 1.4,
      width: MediaQuery.of(context).size.width,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Container(
            child: Column(
          children: [
            StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection("Users")
                    .doc(user.uid)
                    .collection("TotalMarketChat")
                    .doc("MarketChat")
                    .snapshots(),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (snapshot.hasError) {
                    return Text("Error!");
                  } else if (snapshot.connectionState ==
                      ConnectionState.waiting) {
                    return Container();
                  } else {
                    Map<String, dynamic> data =
                        snapshot.data!.data() as Map<String, dynamic>;
                    List chat_id_list = [];

                    if (data["ItemID"].length != 0) {
                      for (int i = 0; i < data["ItemID"].length; i++) {
                        chat_id_list.add(data["ItemID"][i]);
                        print("chat_id_list 값 : " + chat_id_list[i]);
                      }

                      return StreamBuilder(
                          stream: FirebaseFirestore.instance
                              .collection("MarketChatRoom")
                              .snapshots(),
                          builder:
                              (BuildContext context, AsyncSnapshot snapshots) {
                            if (snapshots.hasError) {
                              return Text("Error!");
                            } else if (snapshots.connectionState ==
                                ConnectionState.waiting) {
                              return Container();
                            } else {
                              var datas = snapshots.data!.docs;

                              List nick_name_list = [];
                              List change_nick_name_list = [];
                              List doc_chat_path = [];
                              List last_comment = [];
                              List image_url_list = [];

                              for (int i = 0; i < datas.length; i++) {
                                for (int j = 0; j < chat_id_list.length; j++) {
                                  if (datas[i].id == chat_id_list[j]) {
                                    Map<String, dynamic> data123 =
                                        datas[i].data() as Map<String, dynamic>;
                                    nick_name_list.add(data123["NickName1"]);
                                    change_nick_name_list
                                        .add(data123["NickName2"]);
                                    image_url_list.add(data123["ImageUrl"]);
                                    if (data123["ChatRoom"].length > 0) {
                                      last_comment.add(data123["ChatRoom"]
                                              [data123["ChatRoom"].length - 1]
                                          ["Comment"]);
                                    } else {
                                      last_comment.add("");
                                    }
                                    doc_chat_path.add(datas[i].id);
                                  }
                                }
                              }

                              return Expanded(
                                child: ListView.separated(
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return Container(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        height: 100,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(5)),
                                        child: GestureDetector(
                                          onTap: () {
                                            Navigator.push(context,
                                                MaterialPageRoute(builder:
                                                    (BuildContext context) {
                                              return MarketChatRoom(
                                                  chat_path:
                                                      doc_chat_path[index]);
                                            }));
                                          },
                                          child: Column(
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0, 15, 0, 15),
                                                child: ListTile(
                                                  trailing: SizedBox(
                                                    height: 120,
                                                    width: 100,
                                                    // child: Container(
                                                    //   decoration: BoxDecoration(
                                                    //       color: Colors.grey,
                                                    //       borderRadius:
                                                    //           BorderRadius
                                                    //               .circular(5),
                                                    //       image:
                                                    //           DecorationImage(
                                                    //               image:
                                                    //                   NetworkImage(
                                                    //                 image_url_list[
                                                    //                     index],
                                                    //               ),
                                                    //               fit: BoxFit
                                                    //                   .fill)),
                                                    // ),
                                                    child: image_url_list[
                                                                index] !=
                                                            ""
                                                        ? CachedNetworkImage(
                                                            imageUrl:
                                                                image_url_list[
                                                                    index],
                                                            imageBuilder: (context,
                                                                    imageProvider) =>
                                                                Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                image:
                                                                    DecorationImage(
                                                                  image:
                                                                      imageProvider,
                                                                  fit: BoxFit
                                                                      .fill,
                                                                  // colorFilter: const ColorFilter.mode(
                                                                  //   Colors.red,
                                                                  //   BlendMode.colorBurn,
                                                                  // ),
                                                                ),
                                                              ),
                                                            ),
                                                            placeholder: (context,
                                                                    url) =>
                                                                const CircularProgressIndicator(
                                                              strokeWidth: 1.0,
                                                            ),
                                                            errorWidget: (context,
                                                                    url,
                                                                    error) =>
                                                                const Icon(Icons
                                                                    .error),
                                                          )
                                                        : Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color:
                                                                  Colors.grey,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                            ),
                                                          ),
                                                  ),
                                                  leading: Container(
                                                    width: 40,
                                                    height: 40,
                                                    child: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40),
                                                      child: Image.network(
                                                        'https://www.edmundsgovtech.com/wp-content/uploads/2020/01/default-picture_0_0.png',
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                  ),
                                                  title: Column(
                                                    children: [
                                                      Row(children: [
                                                        Text(
                                                          nick_name_list[
                                                                      index] ==
                                                                  userAccount_
                                                                      .nickname
                                                              ? change_nick_name_list[
                                                                  index]
                                                              : nick_name_list[
                                                                  index],
                                                          style: TextStyle(
                                                              color: Color(
                                                                  0xff58585b),
                                                              fontFamily:
                                                                  'GSANSB',
                                                              fontSize: 16),
                                                        ),
                                                      ]),
                                                      SizedBox(
                                                        height: 15,
                                                      ),
                                                      Row(
                                                        children: [
                                                          Text(
                                                            last_comment[index],
                                                            style: TextStyle(
                                                                color: Color(
                                                                    0xff58585b),
                                                                fontFamily:
                                                                    'GSANSM',
                                                                fontSize: 14),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                    separatorBuilder:
                                        (BuildContext context, int index) {
                                      return Container(
                                        height: 1.5,
                                        color: Colors.grey[200],
                                      );
                                    },
                                    itemCount: nick_name_list.length),
                              );
                            }
                          });
                    } else {
                      return Container(child: Text('\n채팅방이 없습니다.'));
                    }
                  }
                })
          ],
        )),
      ),
    );
  }

  // Widget _total_Market_Item() {
  //   List test = [];
  //   // test.addAll(Market_Item_ID_List);

  //   for (int i = 0; i < Market_Item_ID_List.length; i++) {
  //     test.add(Market_Item_ID_List[i]);
  //   }
  //   Market_Item_ID_List.clear();
  //   return Container(
  //     height: MediaQuery.of(context).size.height / 1.4,
  //     child: FutureBuilder(
  //         future: _getItem(test),
  //         builder: (BuildContext context, AsyncSnapshot snapshot) {
  //           if (snapshot.hasData == false) {
  //             return Container();
  //           } else if (snapshot.hasError) {
  //             return Text("에러에러");
  //           } else if (snapshot.connectionState == ConnectionState.waiting) {
  //             return Container();
  //           } else {
  //             List item_title = [];
  //             List item_intro = [];
  //             List item_price = [];
  //             List item_datetime = [];
  //             List item_nick_name = [];
  //             List item_user_uid = [];
  //             List item_image_url = [];

  //             for (int i = 0; i < data.length; i++) {
  //               item_title.add(data[i]["Title"]);
  //               item_intro.add(data[i]["Intro"]);
  //               item_price.add(data[i]["Price"]);
  //               item_datetime.add(data[i]["DateTime"]);
  //               item_nick_name.add(data[i]["NickName"]);
  //               item_user_uid.add(data[i]["UserUID"]);
  //               for (int j = 0; j < data[i]["ImageUrl"].length; i++) {
  //                 item_image_url.add(data[i]["ImageUrl"][j]);
  //               }
  //             }

  //             return ListView.separated(
  //                 itemBuilder: (BuildContext context, int index) {
  //                   return Container(
  //                     width: MediaQuery.of(context).size.width,
  //                     height: 150,
  //                     decoration: BoxDecoration(
  //                         color: Colors.white,
  //                         borderRadius: BorderRadius.circular(5)),
  //                     child: GestureDetector(
  //                       onTap: () async {
  //                         // Navigator.push(context, MaterialPageRoute(
  //                         //     builder: (BuildContext context) {
  //                         //   return MarketItemInfo(
  //                         //     prev_intro: item_intro[index],
  //                         //     prev_nick_name: item_nick_name[index],
  //                         //     prev_price: item_price[index],
  //                         //     prev_title: item_title[index],
  //                         //     prev_datetime: item_datetime[index],
  //                         //     prev_imageurl: "",
  //                         //     prev_UserUID: item_user_uid[index],
  //                         //   );
  //                         // }));
  //                         final recive = await Navigator.push(context,
  //                             MaterialPageRoute(
  //                                 builder: (BuildContext context) {
  //                           return MarketItemInfo(
  //                             prev_intro: item_intro[index],
  //                             prev_nick_name: item_nick_name[index],
  //                             prev_price: item_price[index],
  //                             prev_title: item_title[index],
  //                             prev_datetime: item_datetime[index],
  //                             prev_imageurl: item_image_url,
  //                             prev_UserUID: item_user_uid[index],
  //                             prev_itemID: '',
  //                           );
  //                         }));
  //                         setState(() {
  //                           if (recive == 2) {
  //                             _tabController.index = 2;
  //                           }
  //                         });
  //                       },
  //                       child: Column(
  //                         // crossAxisAlignment: CrossAxisAlignment.start,
  //                         children: [
  //                           Padding(
  //                             padding: EdgeInsets.fromLTRB(0, 15, 0, 15),
  //                             child: ListTile(
  //                               leading: SizedBox(
  //                                 height: 120,
  //                                 width: 100,
  //                                 child: Container(
  //                                   decoration: BoxDecoration(
  //                                       color: Colors.grey,
  //                                       borderRadius: BorderRadius.circular(5)),
  //                                 ),
  //                               ),
  //                               title: Column(
  //                                 children: [
  //                                   Row(children: [
  //                                     Text(
  //                                       item_title[index],
  //                                       style: TextStyle(
  //                                           color: Color(0xff58585b),
  //                                           fontFamily: 'GSANSM',
  //                                           fontSize: 14),
  //                                     ),
  //                                   ]),
  //                                   SizedBox(
  //                                     height: 10.0,
  //                                   ),
  //                                   Row(children: [
  //                                     Text(
  //                                       item_datetime[index],
  //                                       style: TextStyle(
  //                                           color: Colors.grey[400],
  //                                           fontFamily: 'GSANSM',
  //                                           fontSize: 12),
  //                                     ),
  //                                   ]),
  //                                   SizedBox(
  //                                     height: 10.0,
  //                                   ),
  //                                   Row(children: [
  //                                     Text(
  //                                       item_price[index],
  //                                       style: TextStyle(
  //                                           color: Colors.grey[400],
  //                                           fontFamily: 'GSANSB',
  //                                           fontSize: 13),
  //                                     ),
  //                                   ]),
  //                                 ],
  //                               ),
  //                               // subtitle: Text(
  //                               //   b[index],
  //                               //   style: TextStyle(
  //                               //       color: Color(0xff9f9f9f),
  //                               //       fontFamily: 'GSANSM',
  //                               //       fontSize: 12.0),
  //                               // ),
  //                               // trailing: Padding(
  //                               //   padding: EdgeInsets.fromLTRB(0, 25, 0, 0),
  //                               //   child: Text(
  //                               //     item_price[index],
  //                               //     style: TextStyle(
  //                               //         color: Color(0xff9f9f9f),
  //                               //         fontFamily: 'GSANSM',
  //                               //         fontSize: 12.0),
  //                               //   ),
  //                               // ),
  //                             ),
  //                           ),
  //                         ],
  //                       ),
  //                     ),
  //                     // child: GestureDetector(
  //                     //   onTap: () {},
  //                     //   child: Padding(
  //                     //     padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
  //                     //     child: Row(
  //                     //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                     //       children: [
  //                     //         Text(
  //                     //           item_title[index],
  //                     //           style: TextStyle(
  //                     //               fontFamily: 'GSANSM',
  //                     //               color: Color(0xff58585b),
  //                     //               fontSize: 14),
  //                     //         ),
  //                     //         Text(item_intro[index],
  //                     //             style: TextStyle(
  //                     //                 fontFamily: 'GSANSM',
  //                     //                 color: Color(0xff58585b),
  //                     //                 fontSize: 14)),
  //                     //         Text(
  //                     //           item_price[index],
  //                     //           style: TextStyle(
  //                     //               fontFamily: 'GSANSM',
  //                     //               color: Color(0xff9f9f9f),
  //                     //               fontSize: 12),
  //                     //         ),
  //                     //       ],
  //                     //     ),
  //                     //   ),
  //                     // )
  //                   );
  //                 },
  //                 separatorBuilder: (BuildContext context, int index) {
  //                   return Container(
  //                     height: 1.5,
  //                     color: Colors.grey[200],
  //                   );
  //                 },
  //                 itemCount: item_title.length);
  //           }
  //         }),
  //   );
  // }

  Widget _total_Market_Item_another() {
    data.clear();
    return Container(
      height: MediaQuery.of(context).size.height / 1.4,
      child: FutureBuilder(
          future: FirebaseFirestore.instance.collection("Market").get(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (snapshot.hasData == false) {
              return Container();
            } else if (snapshot.hasError) {
              return Text("에러");
            } else if (snapshot.connectionState == ConnectionState.waiting) {
              return Container();
            } else {
              List total_item_data = [];

              for (int i = 0; i < snapshot.data.docs.length; i++) {
                total_item_data.add(snapshot.data.docs[i].id);
              }
              data.clear();
              return FutureBuilder(
                  future: _getItem(total_item_data),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData == false) {
                      return Container();
                    } else if (snapshot.hasError) {
                      return Text("에러에러");
                    } else if (snapshot.connectionState ==
                        ConnectionState.waiting) {
                      return Container();
                    } else {
                      List item_title = [];
                      List item_intro = [];
                      List item_price = [];
                      List item_datetime = [];
                      List item_nick_name = [];
                      List item_user_uid = [];
                      List item_image_url = [];
                      List item_id = [];

                      // for (int i = 0; i < data.length; i++) {
                      //   item_title.add(data[i]["Title"]);
                      //   item_intro.add(data[i]["Intro"]);
                      //   item_price.add(data[i]["Price"]);
                      //   item_datetime.add(data[i]["DateTime"]);
                      //   item_nick_name.add(data[i]["NickName"]);
                      //   item_user_uid.add(data[i]["UserUID"]);
                      //   item_id.add(data[i]["ItemID"]);
                      //   for (int j = 0; j < data[i]["ImageUrl"].length; j++) {
                      //     item_image_url.add(data[i]["ImageUrl"][j]);
                      //   }
                      // }

                      for (int i = 0; i < data.length; i++) {
                        item_title.add(data[i]["Title"]);
                        item_intro.add(data[i]["Intro"]);
                        item_price.add(data[i]["Price"]);
                        item_datetime.add(data[i]["DateTime"]);
                        item_nick_name.add(data[i]["NickName"]);
                        item_user_uid.add(data[i]["UserUID"]);
                        item_id.add(data[i]["ItemID"]);
                        item_image_url.add(data[i]["ImageUrl"]);
                        // for (int j = 0; j < data[i]["ImageUrl"].length; j++) {
                        //   test.add({i: data[i]["ImageUrl"][j]});
                        // }
                      }

                      return ListView.separated(
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              width: MediaQuery.of(context).size.width,
                              height: 100,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5)),
                              child: GestureDetector(
                                onTap: () async {
                                  // Navigator.push(context, MaterialPageRoute(
                                  //     builder: (BuildContext context) {
                                  //   return MarketItemInfo(
                                  //     prev_intro: item_intro[index],
                                  //     prev_nick_name: item_nick_name[index],
                                  //     prev_price: item_price[index],
                                  //     prev_title: item_title[index],
                                  //     prev_datetime: item_datetime[index],
                                  //     prev_imageurl: "",
                                  //     prev_UserUID: item_user_uid[index],
                                  //   );
                                  // }));
                                  final recive = await Navigator.push(context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) {
                                    return MarketItemInfo(
                                        prev_intro: item_intro[index],
                                        prev_nick_name: item_nick_name[index],
                                        prev_price: item_price[index],
                                        prev_title: item_title[index],
                                        prev_datetime: item_datetime[index],
                                        prev_imageurl: item_image_url[index],
                                        prev_UserUID: item_user_uid[index],
                                        prev_itemID: item_id[index],
                                        prev_test: [""]);
                                  }));
                                  setState(() {
                                    if (recive == 2) {
                                      _tabController.index = 2;
                                    }
                                  });
                                },
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding:
                                          EdgeInsets.fromLTRB(0, 15, 0, 15),
                                      child: ListTile(
                                        leading: SizedBox(
                                          height: 120,
                                          width: 100,
                                          // child: Container(
                                          //   decoration: BoxDecoration(
                                          //       color: Colors.grey,
                                          //       borderRadius:
                                          //           BorderRadius.circular(5),
                                          //       image: DecorationImage(
                                          //           image: NetworkImage(

                                          //               item_image_url[index]),
                                          //           fit: BoxFit.fill)
                                          //           ),
                                          //   child: CachedNetworkImage(
                                          //     imageUrl: item_image_url[index],
                                          //     placeholder: (context, url) =>
                                          //         const CircularProgressIndicator(
                                          //       strokeWidth: 1.0,

                                          //     ),

                                          //   ),
                                          // ),
                                          child: item_image_url[index] != ""
                                              ? CachedNetworkImage(
                                                  imageUrl:
                                                      item_image_url[index],
                                                  imageBuilder: (context,
                                                          imageProvider) =>
                                                      Container(
                                                    decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                        image: imageProvider,
                                                        fit: BoxFit.fill,
                                                        // colorFilter: const ColorFilter.mode(
                                                        //   Colors.red,
                                                        //   BlendMode.colorBurn,
                                                        // ),
                                                      ),
                                                    ),
                                                  ),
                                                  placeholder: (context, url) =>
                                                      const CircularProgressIndicator(
                                                    strokeWidth: 1.0,
                                                  ),
                                                  errorWidget: (context, url,
                                                          error) =>
                                                      const Icon(Icons.error),
                                                )
                                              : Container(
                                                  decoration: BoxDecoration(
                                                    color: Colors.grey,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5),
                                                  ),
                                                ),
                                        ),
                                        // leading: ExtendedImage.network(
                                        //     total_image_list[index],
                                        //     width: 200,
                                        //     height: 200,
                                        //     fit: BoxFit.fill,
                                        //     cache: true,
                                        //     border: Border.all(
                                        //         color: Colors.red, width: 1.0),
                                        //     shape: BoxShape.circle,
                                        //     borderRadius: BorderRadius.all(
                                        //         Radius.circular(30.0))),
                                        title: Column(
                                          children: [
                                            Row(children: [
                                              Text(
                                                item_title[index],
                                                style: TextStyle(
                                                    color: Color(0xff58585b),
                                                    fontFamily: 'GSANSM',
                                                    fontSize: 14),
                                              ),
                                            ]),
                                            SizedBox(
                                              height: 10.0,
                                            ),
                                            Row(children: [
                                              Text(
                                                item_datetime[index],
                                                style: TextStyle(
                                                    color: Colors.grey[400],
                                                    fontFamily: 'GSANSM',
                                                    fontSize: 12),
                                              ),
                                            ]),
                                            SizedBox(
                                              height: 10.0,
                                            ),
                                            Row(children: [
                                              Text(
                                                item_price[index],
                                                style: TextStyle(
                                                    color: Colors.grey[400],
                                                    fontFamily: 'GSANSB',
                                                    fontSize: 13),
                                              ),
                                            ]),
                                          ],
                                        ),
                                        // subtitle: Text(
                                        //   b[index],
                                        //   style: TextStyle(
                                        //       color: Color(0xff9f9f9f),
                                        //       fontFamily: 'GSANSM',
                                        //       fontSize: 12.0),
                                        // ),
                                        // trailing: Padding(
                                        //   padding: EdgeInsets.fromLTRB(0, 25, 0, 0),
                                        //   child: Text(
                                        //     item_price[index],
                                        //     style: TextStyle(
                                        //         color: Color(0xff9f9f9f),
                                        //         fontFamily: 'GSANSM',
                                        //         fontSize: 12.0),
                                        //   ),
                                        // ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // child: GestureDetector(
                              //   onTap: () {},
                              //   child: Padding(
                              //     padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              //     child: Row(
                              //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              //       children: [
                              //         Text(
                              //           item_title[index],
                              //           style: TextStyle(
                              //               fontFamily: 'GSANSM',
                              //               color: Color(0xff58585b),
                              //               fontSize: 14),
                              //         ),
                              //         Text(item_intro[index],
                              //             style: TextStyle(
                              //                 fontFamily: 'GSANSM',
                              //                 color: Color(0xff58585b),
                              //                 fontSize: 14)),
                              //         Text(
                              //           item_price[index],
                              //           style: TextStyle(
                              //               fontFamily: 'GSANSM',
                              //               color: Color(0xff9f9f9f),
                              //               fontSize: 12),
                              //         ),
                              //       ],
                              //     ),
                              //   ),
                              // )
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return Container(
                              height: 1.5,
                              color: Colors.grey[200],
                            );
                          },
                          itemCount: item_title.length);
                    }
                  });
            }
          }),
    );
  }

  Widget buy_sell_List() {
    return Container(
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(15, 30, 15, 20),
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 100,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () async {
                      final recive = await Navigator.push(context,
                          MaterialPageRoute(builder: (BuildContext context) {
                        return UserBuyList();
                      }));
                      setState(() {
                        if (recive == 2) {
                          _tabController.index = 2;
                        }
                      });
                    },
                    child: Image.asset(
                      "assets/images/PNG/buy.png",
                      width: 140,
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      final recive = await Navigator.push(context,
                          MaterialPageRoute(builder: (BuildContext context) {
                        return USerSellList();
                      }));
                      setState(() {
                        if (recive == 2) {
                          _tabController.index = 2;
                        }
                      });
                    },
                    child: Image.asset(
                      "assets/images/PNG/sell.png",
                      width: 140,
                    ),
                  )
                ],
              ),
            ),
          ),
          // GestureDetector(
          //   onTap: () {
          //     Navigator.push(context,
          //         MaterialPageRoute(builder: (BuildContext context) {
          //       return UserBuyList();
          //     }));
          //   },
          //   child: SvgPicture.asset("assets/images/SVG/buy.svg"),
          // ),
          // GestureDetector(
          //   onTap: () {
          //     print("sell");
          //   },
          //   child: SvgPicture.asset("assets/images/SVG/sell.svg"),
          // )
        ],
      ),
    );
  }

  late TabController _tabController =
      new TabController(length: 3, vsync: this, initialIndex: 0);

  @override
  void initState() {
    // TODO: implement initState

    _tabController = TabController(length: 3, vsync: this, initialIndex: 0);

    // if (returnNum == 2) {
    //   _tabController.index = 2;
    // }

    _tabController.addListener(_switchTabIndex);

    super.initState();
  }

  void _switchTabIndex() {
    print(_tabController.index);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    UserAccountInfo userAccount_ = Provider.of(context, listen: false);
    // _getData();

    // _get_Market_Chat_Room_Id();
    data.clear();

    return WillPopScope(
      onWillPop: () {
        setState(() {
          print("back press 실행");
        });
        if (_tabController.index == 1 || _tabController.index == 2) {
          _tabController.index = 0;
          return Future(() => false);
        } else {
          return Future(() => true);
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Color(0xFFFFFFFF),
          iconTheme: IconThemeData(color: Colors.grey),
          title:
              // Image.asset(
              //   'assets/images/PNG/logo2.png',
              //   width: 110,
              // ),
              SvgPicture.asset(
            'assets/images/SVG/LOGO_KAMMON_small.svg',
            width: 110,
          ),
          actions: [],
          centerTitle: true,
          elevation: 0,
          bottom: TabBar(
              indicatorColor: Color(0xffe83a4f),
              indicatorWeight: 3.0,
              controller: _tabController,
              unselectedLabelColor: Colors.black,
              tabs: [
                Tab(
                  child: Text(
                    "MAIN",
                    style: TextStyle(
                        fontFamily: 'GSANSM',
                        fontSize: 14,
                        color: Color(0xff58585b)),
                  ),
                ),
                Tab(
                  child: Text(
                    "거래내역",
                    style: TextStyle(
                        fontFamily: 'GSANSM',
                        fontSize: 14,
                        color: Color(0xff58585b)),
                  ),
                ),
                Tab(
                  child: Text(
                    "채팅",
                    style: TextStyle(
                        fontFamily: 'GSANSM',
                        fontSize: 14,
                        color: Color(0xff58585b)),
                  ),
                ),
              ]),
        ),
        floatingActionButton: CircularMenu(
          // menu alignment
          alignment: Alignment.bottomRight,
          // menu radius
          radius: 70,
          // widget in the background holds actual page content
          //backgroundWidget: MyCustomWidget(),
          // global key to control the animation anywhere in the code.
          key: GlobalKey<CircularMenuState>(),
          // animation duration
          animationDuration: Duration(milliseconds: 300),
          // animation curve in forward
          curve: Curves.easeInOut,
          // animation curve in reverse
          reverseCurve: Curves.fastOutSlowIn,
          // first item angle
          //startingAngleInRadian : 0 ,
          // last item angle
          //endingAngleInRadian : 3.141592 * 3,
          // toggle button callback
          toggleButtonOnPressed: () {
            //callback
          },
          // toggle button appearance properties
          toggleButtonColor: Theme.of(context).primaryColor,
          toggleButtonBoxShadow: [
            BoxShadow(
              color: Theme.of(context).primaryColor,
              blurRadius: 1,
            ),
          ],
          //toggleButtonAnimatedIconData: AnimatedIcons.add_event,

          toggleButtonIconColor: Colors.white,
          toggleButtonMargin: 10.0,
          toggleButtonPadding: 10.0,
          toggleButtonSize: 30.0,
          items: [
            CircularMenuItem(
                iconSize: 30,
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).primaryColor,
                    blurRadius: 1,
                  ),
                ],
                icon: Icons.groups,
                color: Theme.of(context).primaryColor,
                onTap: () {}),
            CircularMenuItem(
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).primaryColor,
                    blurRadius: 1,
                  ),
                ],
                icon: Icons.post_add,
                color: Theme.of(context).primaryColor,
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                    return MarketItemPostWrite();
                  }));
                }),
          ],
        ),
        // body: SafeArea(
        //   child: Container(
        //     width: MediaQuery.of(context).size.width,
        //     height: MediaQuery.of(context).size.height,
        //     child: Padding(
        //       padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
        //       child: Column(
        //         children: [
        //           Divider(thickness: 1.5, height: 1.5, color: Colors.grey[200]),
        //           _total_Market_Item(),
        //         ],
        //       ),
        //     ),
        //   ),
        // ),
        body: TabBarView(controller: _tabController, children: [
          SafeArea(
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: Column(
                  children: [
                    // Divider(
                    //     thickness: 1.5, height: 1.5, color: Colors.grey[200]),
                    // _total_Market_Item(),
                    // _total_Market_Item_another()

                    MarketRequestPage(
                      parentAction: _updateMyIndex,
                    )
                  ],
                ),
              ),
            ),
          ),
          buy_sell_List(),
          SafeArea(
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              child: Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: Column(
                  children: [
                    // Divider(
                    //     thickness: 1.5, height: 1.5, color: Colors.grey[200]),
                    _market_Chat_Room(),
                  ],
                ),
              ),
            ),
          ),
          // _market_Chat_Room()
        ]),
        bottomNavigationBar: SizedBox(
        height: 60,
        child: Container(
          decoration: BoxDecoration(
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Colors.black54,
                  blurRadius: 5.0,
                  offset: Offset(0.0, 0.75)
              )
            ],
          ),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            //backgroundColor: Colors.grey[300],
            backgroundColor: Colors.white,
            elevation: 3,
            selectedItemColor: Theme.of(context).primaryColor,
            //selectedItemColor: Colors.grey[800],
            currentIndex: _selectedNaviIndex,
            onTap: (int index) {
              _selectedNaviIndex = index;
              setState(() {
                if(_selectedNaviIndex == 0) { 
                  print(_selectedNaviIndex);
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context){
                        return Home();
                      }
                  ));
                }
                if(_selectedNaviIndex == 1) { 
                  print(_selectedNaviIndex);
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context){
                        return InstantPLay();
                      }
                  ));
                }
                if(_selectedNaviIndex == 2) { 
                  print(_selectedNaviIndex);
                  Navigator.push(context, MaterialPageRoute(
                      builder: (BuildContext context){
                        return FirstScreen();
                      }
                  ));
                }
                if(_selectedNaviIndex == 3) { 
                  Navigator.push(context, MaterialPageRoute(
                    builder: (BuildContext context){
                      return MarketMainPage(item_id: userAccount_.marketChatItem);
                    }
                  ));
                }
              });
            },
            items: [
              BottomNavigationBarItem(
                title: Text('홈', style: TextStyle(fontFamily: 'GSANSM', fontSize: 11),),
                icon: SvgPicture.asset('assets/images/SVG/home.svg', width: 23,),
                activeIcon: SvgPicture.asset('assets/images/SVG/home_selected.svg', width: 23,),
              ),
              BottomNavigationBarItem(
                title: Text('벙개', style: TextStyle(fontFamily: 'GSANSM', fontSize: 11),),
                icon: SvgPicture.asset('assets/images/SVG/light.svg', width: 23,),
                activeIcon: SvgPicture.asset('assets/images/SVG/light_selected.svg', width: 23,),
              ),
              BottomNavigationBarItem(
                title: Text('클럽', style: TextStyle(fontFamily: 'GSANSM', fontSize: 11)),
                icon: SvgPicture.asset('assets/images/SVG/club.svg', width: 23,),
                activeIcon: SvgPicture.asset('assets/images/SVG/club_selected.svg', width: 23,),
              ),
              BottomNavigationBarItem(
                title: Text('중고장터', style: TextStyle(fontFamily: 'GSANSM', fontSize: 11),),
                icon: SvgPicture.asset('assets/images/SVG/basket.svg', width: 23,),
                activeIcon: SvgPicture.asset('assets/images/SVG/basket_selected.svg', width: 23,),
              ),
              BottomNavigationBarItem(
                title: Text('더보기', style: TextStyle(fontFamily: 'GSANSM', fontSize: 11)),
                icon: SvgPicture.asset('assets/images/SVG/more.svg', width: 23,),
                activeIcon: SvgPicture.asset('assets/images/SVG/more_selected.svg', width: 23,),
              ),
            ],
          )
        )
      ),
      ),
    );
  }

  _updateMyIndex(int chage_index) {
    setState(() {
      _tabController.index = chage_index;
    });
  }
}

class MarketRequestPage extends StatefulWidget {
  final ValueChanged<int> parentAction;
  const MarketRequestPage({Key? key, required this.parentAction})
      : super(key: key);

  @override
  _MarketRequestPageState createState() => _MarketRequestPageState();
}

class _MarketRequestPageState extends State<MarketRequestPage>
    with AutomaticKeepAliveClientMixin {
  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
  List data = [];

  User user = FirebaseAuth.instance.currentUser!;

  Future _getItem(List item_id) async {
    print("_getItem 호출함");
    // List image_list = [];
    // data.clear();

    CollectionReference refMarket =
        FirebaseFirestore.instance.collection("Market");

    for (int i = 0; i < item_id.length; i++) {
      DocumentSnapshot snapitemshot = await refMarket.doc(item_id[i]).get();

      data.add(snapitemshot.data());
    }

    return data;
  }

  @override
  Widget build(BuildContext context) {
    UserAccountInfo userAccount_ = Provider.of(context, listen: false);
    return Container(
      height: MediaQuery.of(context).size.height / 1.4,
      child: FutureBuilder(
          future: FirebaseFirestore.instance.collection("Market").get(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (snapshot.hasData == false) {
              return Container();
            } else if (snapshot.hasError) {
              return Text("에러");
            } else if (snapshot.connectionState == ConnectionState.waiting) {
              return Container();
            } else {
              List total_item_data = [];

              for (int i = 0; i < snapshot.data.docs.length; i++) {
                total_item_data.add(snapshot.data.docs[i].id);
              }
              data.clear();
              return FutureBuilder(
                  future: _getItem(total_item_data),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.hasData == false) {
                      return Container();
                    } else if (snapshot.hasError) {
                      return Text("에러에러");
                    } else if (snapshot.connectionState ==
                        ConnectionState.waiting) {
                      return Container();
                    } else {
                      List item_title = [];
                      List item_intro = [];
                      List item_price = [];
                      List item_datetime = [];
                      List item_nick_name = [];
                      List item_user_uid = [];
                      List item_image_url = [];
                      List item_id = [];

                      // for (int i = 0; i < data.length; i++) {
                      //   item_title.add(data[i]["Title"]);
                      //   item_intro.add(data[i]["Intro"]);
                      //   item_price.add(data[i]["Price"]);
                      //   item_datetime.add(data[i]["DateTime"]);
                      //   item_nick_name.add(data[i]["NickName"]);
                      //   item_user_uid.add(data[i]["UserUID"]);
                      //   item_id.add(data[i]["ItemID"]);
                      //   for (int j = 0; j < data[i]["ImageUrl"].length; j++) {
                      //     item_image_url.add(data[i]["ImageUrl"][j]);
                      //   }
                      // }

                      for (int i = 0; i < data.length; i++) {
                        item_title.add(data[i]["Title"]);
                        item_intro.add(data[i]["Intro"]);
                        item_price.add(data[i]["Price"]);
                        item_datetime.add(data[i]["DateTime"]);
                        item_nick_name.add(data[i]["NickName"]);
                        item_user_uid.add(data[i]["UserUID"]);
                        item_id.add(data[i]["ItemID"]);
                        item_image_url.add(data[i]["ImageUrl"]);
                        // for (int j = 0; j < data[i]["ImageUrl"].length; j++) {
                        //   test.add({i: data[i]["ImageUrl"][j]});
                        // }
                      }

                      return ListView.separated(
                          itemBuilder: (BuildContext context, int index) {
                            return Container(
                              width: MediaQuery.of(context).size.width,
                              height: 100,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(5)),
                              child: GestureDetector(
                                onTap: () async {
                                  // Navigator.push(context, MaterialPageRoute(
                                  //     builder: (BuildContext context) {
                                  //   return MarketItemInfo(
                                  //     prev_intro: item_intro[index],
                                  //     prev_nick_name: item_nick_name[index],
                                  //     prev_price: item_price[index],
                                  //     prev_title: item_title[index],
                                  //     prev_datetime: item_datetime[index],
                                  //     prev_imageurl: "",
                                  //     prev_UserUID: item_user_uid[index],
                                  //   );
                                  // }));
                                  final recive = await Navigator.push(context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) {
                                    return MarketItemInfo(
                                        prev_intro: item_intro[index],
                                        prev_nick_name: item_nick_name[index],
                                        prev_price: item_price[index],
                                        prev_title: item_title[index],
                                        prev_datetime: item_datetime[index],
                                        prev_imageurl: item_image_url[index],
                                        prev_UserUID: item_user_uid[index],
                                        prev_itemID: item_id[index],
                                        prev_test: [""]);
                                  }));
                                  setState(() {
                                    if (recive == 2) {
                                      widget.parentAction(2);
                                    }
                                  });
                                },
                                child: Column(
                                  // crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding:
                                          EdgeInsets.fromLTRB(0, 15, 0, 15),
                                      child: ListTile(
                                        leading: SizedBox(
                                          height: 120,
                                          width: 100,
                                          // child: Container(
                                          //   decoration: BoxDecoration(
                                          //       color: Colors.grey,
                                          //       borderRadius:
                                          //           BorderRadius.circular(5),
                                          //       image: DecorationImage(
                                          //           image: NetworkImage(

                                          //               item_image_url[index]),
                                          //           fit: BoxFit.fill)
                                          //           ),
                                          //   child: CachedNetworkImage(
                                          //     imageUrl: item_image_url[index],
                                          //     placeholder: (context, url) =>
                                          //         const CircularProgressIndicator(
                                          //       strokeWidth: 1.0,

                                          //     ),

                                          //   ),
                                          // ),
                                          child: item_image_url[index] != ""
                                              ? CachedNetworkImage(
                                                  imageUrl:
                                                      item_image_url[index],
                                                  imageBuilder: (context,
                                                          imageProvider) =>
                                                      Container(
                                                    decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                        image: imageProvider,
                                                        fit: BoxFit.fill,
                                                        // colorFilter: const ColorFilter.mode(
                                                        //   Colors.red,
                                                        //   BlendMode.colorBurn,
                                                        // ),
                                                      ),
                                                    ),
                                                  ),
                                                  placeholder: (context, url) =>
                                                      const CircularProgressIndicator(
                                                    strokeWidth: 1.0,
                                                  ),
                                                  errorWidget: (context, url,
                                                          error) =>
                                                      const Icon(Icons.error),
                                                )
                                              : Container(
                                                  decoration: BoxDecoration(
                                                    color: Colors.grey,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5),
                                                  ),
                                                ),
                                        ),
                                        // leading: ExtendedImage.network(
                                        //     total_image_list[index],
                                        //     width: 200,
                                        //     height: 200,
                                        //     fit: BoxFit.fill,
                                        //     cache: true,
                                        //     border: Border.all(
                                        //         color: Colors.red, width: 1.0),
                                        //     shape: BoxShape.circle,
                                        //     borderRadius: BorderRadius.all(
                                        //         Radius.circular(30.0))),
                                        title: Column(
                                          children: [
                                            Row(children: [
                                              Text(
                                                item_title[index],
                                                style: TextStyle(
                                                    color: Color(0xff58585b),
                                                    fontFamily: 'GSANSM',
                                                    fontSize: 14),
                                              ),
                                            ]),
                                            SizedBox(
                                              height: 10.0,
                                            ),
                                            Row(children: [
                                              Text(
                                                item_datetime[index],
                                                style: TextStyle(
                                                    color: Colors.grey[400],
                                                    fontFamily: 'GSANSM',
                                                    fontSize: 12),
                                              ),
                                            ]),
                                            SizedBox(
                                              height: 10.0,
                                            ),
                                            Row(children: [
                                              Text(
                                                item_price[index],
                                                style: TextStyle(
                                                    color: Colors.grey[400],
                                                    fontFamily: 'GSANSB',
                                                    fontSize: 13),
                                              ),
                                            ]),
                                          ],
                                        ),
                                        // subtitle: Text(
                                        //   b[index],
                                        //   style: TextStyle(
                                        //       color: Color(0xff9f9f9f),
                                        //       fontFamily: 'GSANSM',
                                        //       fontSize: 12.0),
                                        // ),
                                        // trailing: Padding(
                                        //   padding: EdgeInsets.fromLTRB(0, 25, 0, 0),
                                        //   child: Text(
                                        //     item_price[index],
                                        //     style: TextStyle(
                                        //         color: Color(0xff9f9f9f),
                                        //         fontFamily: 'GSANSM',
                                        //         fontSize: 12.0),
                                        //   ),
                                        // ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // child: GestureDetector(
                              //   onTap: () {},
                              //   child: Padding(
                              //     padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              //     child: Row(
                              //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              //       children: [
                              //         Text(
                              //           item_title[index],
                              //           style: TextStyle(
                              //               fontFamily: 'GSANSM',
                              //               color: Color(0xff58585b),
                              //               fontSize: 14),
                              //         ),
                              //         Text(item_intro[index],
                              //             style: TextStyle(
                              //                 fontFamily: 'GSANSM',
                              //                 color: Color(0xff58585b),
                              //                 fontSize: 14)),
                              //         Text(
                              //           item_price[index],
                              //           style: TextStyle(
                              //               fontFamily: 'GSANSM',
                              //               color: Color(0xff9f9f9f),
                              //               fontSize: 12),
                              //         ),
                              //       ],
                              //     ),
                              //   ),
                              // )
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return Container(
                              height: 1.5,
                              color: Colors.grey[200],
                            );
                          },
                          itemCount: item_title.length);
                    }
                  });
            }
          }),
    );
  }
}
